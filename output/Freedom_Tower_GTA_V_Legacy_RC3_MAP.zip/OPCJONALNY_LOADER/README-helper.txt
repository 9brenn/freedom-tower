OPTIONAL: automatyczne wlaczanie map MP w trybie fabularnym

Wymagania: GTA V Legacy, Script Hook V oraz ScriptHookVDotNet
v3.7.0-nightly.198 lub zgodna nowsza wersja API v3.
Oficjalne wydanie wykorzystane do sprawdzenia kompilacji:
https://github.com/scripthookvdotnet/scripthookvdotnet-nightly/releases/tag/v3.7.0-nightly.198

Skopiuj FreedomTowerLegacy.dll do folderu scripts gry. Alternatywnie
uzyj zrodla FreedomTowerLegacy.3.cs; nie instaluj obu plikow naraz.
Jesli trener juz wlacza MP Maps, helper nie jest konieczny.

Helper po zakonczeniu ladowania jednorazowo wlacza lokalne mapy GTA Online
w Story Mode i prosi o zaladowanie 17 niestandardowych map budynku.
Nie laczy sie z GTA Online. Nie zawiera wind ani teleportacji.
Wlaczenie map MP przeladowuje fragmenty mapy i moze pokazac ekran ladowania.
Po usunieciu helpera zamknij i ponownie uruchom gre, aby przywrocic
domyslny tryb map. Helper celowo nie wylacza map MP przy przeadowaniu
skryptow, poniewaz mogloby to zaklocic dzialanie innych modow.

Weryfikacja: kompilacja .NET Framework 4.8 przeciw oficjalnej bibliotece
ScriptHookVDotNet3.dll wydania nightly.198: 0 bledow, 0 ostrzezen.
Nie wykonano testu w uruchomionej grze GTA V.

Sygnatury natives zweryfikowano w repozytorium citizenfx/natives:
DLC/OnEnterMp.md: void ON_ENTER_MP(), 0x0888C3502DBBEEF5
MISC/SetInstancePriorityMode.md: void SET_INSTANCE_PRIORITY_MODE(int),
0x9BAE5AD2508DF078. Dokumentacja SHVDN zaleca CallLongBlockingFunc
dla ON_ENTER_MP, aby uniknac limitu czasu skryptu.
